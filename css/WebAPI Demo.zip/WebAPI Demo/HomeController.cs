﻿using PhysicianHubApplication.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace PhysicianHubApplication.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SearchPhysician()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Search(int? page, int? limit, string sortBy, string direction, Physician objUser=null)
        {
            string URL = "api/SearchPhysician";

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:53120/"); //Service hosted on different port

            client.DefaultRequestHeaders.Accept.Add(
               new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage response = client.PostAsJsonAsync(URL, objUser).Result;

            List<Physician> objphysicianList = null;
            if (response.IsSuccessStatusCode)
            {
                objphysicianList = response.Content.ReadAsAsync<IEnumerable<Physician>>().Result.ToList<Physician>();
            }


            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(direction))
            {
                if (direction.Trim().ToLower() == "asc")
                {
                    switch (sortBy.Trim().ToLower())
                    {
                        case "firstname":
                            objphysicianList = objphysicianList.OrderBy(q => q.FirstName).ToList<Physician>();
                            break;
                        case "lastname":
                            objphysicianList = objphysicianList.OrderBy(q => q.LastName).ToList<Physician>();
                            break;
                        case "location":
                            objphysicianList = objphysicianList.OrderBy(q => q.Location).ToList<Physician>();
                            break;
                        case "co_id":
                            objphysicianList = objphysicianList.OrderBy(q => q.CO_ID).ToList<Physician>();
                            break;
                        case "hospitalname":
                            objphysicianList = objphysicianList.OrderBy(q => q.HospitalName).ToList<Physician>();
                            break;
                        case "physiciancode":
                            objphysicianList = objphysicianList.OrderBy(q => q.PhysicianCode).ToList<Physician>();
                            break;
                        case "npi":
                            objphysicianList = objphysicianList.OrderBy(q => q.NPINumber).ToList<Physician>();
                            break;
                        case "speciality":
                            objphysicianList = objphysicianList.OrderBy(q => q.Speciality).ToList<Physician>();
                            break;

                    }
                }
                else
                {
                    switch (sortBy.Trim().ToLower())
                    {
                        case "firstname":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.FirstName).ToList<Physician>();
                            break;
                        case "lastname":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.LastName).ToList<Physician>();
                            break;
                        case "location":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.Location).ToList<Physician>();
                            break;
                        case "co_id":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.CO_ID).ToList<Physician>();
                            break;
                        case "hospitalname":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.HospitalName).ToList<Physician>();
                            break;
                        case "physiciancode":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.PhysicianCode).ToList<Physician>();
                            break;
                        case "npi":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.NPINumber).ToList<Physician>();
                            break;
                        case "speciality":
                            objphysicianList = objphysicianList.OrderByDescending(q => q.Speciality).ToList<Physician>();
                            break;
                    }
                }
            }
            else
            {
                objphysicianList = objphysicianList.OrderBy(q => q.CO_ID).ToList<Physician>();
            }


            var total = objphysicianList.Count();
            List<Physician> records = null;

            if (page.HasValue && limit.HasValue)
            {
                if (total > limit)
                {
                    int start = (page.Value - 1) * limit.Value;
                    records = objphysicianList.Skip(start).Take(limit.Value).ToList();
                }
                else
                {
                    records = objphysicianList.ToList();
                }
                
            }
            else
            {
                records = objphysicianList.ToList();
            }
            return this.Json(new { records, total }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Login(string userid, string password)
        {

            User objUser = new User();
            objUser.UserId = userid;
            objUser.Password = password;

            string URL = "api/Authenticate";

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:56430/");//Service hosted on different port

            client.DefaultRequestHeaders.Accept.Add(
               new MediaTypeWithQualityHeaderValue("application/json"));


            HttpResponseMessage response = client.PostAsJsonAsync(URL, objUser).Result;

            
            var answer="";
            if (response.IsSuccessStatusCode)
            {
                answer = response.Content.ReadAsAsync<string>().Result;
            }

            if (answer == "Valid")
            {
                return RedirectToAction("SearchPhysician");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }
	}
}